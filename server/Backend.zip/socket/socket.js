const jwt =
    require("jsonwebtoken");

const CommentModel = require("../models/commentModel");

const NotificationModel = require("../models/NotificationModel");
const GroupChatModel = require("../models/groupChatModel");



const initSocket = (io) => {


    // =========================================
    // AUTHENTICATE SOCKET
    // =========================================

    io.use((socket, next) => {

        try {

            console.log(
                "🔐 Socket authentication..."
            );


            const token =
                socket.handshake.auth?.token;


            if (!token) {

                console.log(
                    "❌ Socket token missing"
                );

                return next(
                    new Error(
                        "No token provided"
                    )
                );

            }


            const cleanToken =
                token.replace(
                    "Bearer ",
                    ""
                );


            const decoded =
                jwt.verify(
                    cleanToken,
                    process.env.JWT_SECRET
                );


            console.log(
                "✅ Socket JWT:",
                decoded
            );


            // Attach user to socket
            socket.user =
                decoded;


            next();


        } catch (error) {

            console.error(
                "❌ Socket authentication failed:",
                error.message
            );


            next(
                new Error(
                    "Invalid token"
                )
            );

        }

    });


    // =========================================
    // CONNECTION
    // =========================================

    io.on(
        "connection",
        (socket) => {


            console.log(
                "🔥 Socket connected:",
                socket.id
            );


            console.log(
                "👤 Socket user:",
                socket.user
            );


            // Safety check
            if (
                !socket.user ||
                !socket.user.id
            ) {

                console.log(
                    "❌ Socket user ID missing"
                );

                socket.disconnect();

                return;

            }


            const userId =
                socket.user.id;


            // =====================================
            // PERSONAL NOTIFICATION ROOM
            // =====================================

            const notificationRoom =
                `user_${userId}`;


            socket.join(
                notificationRoom
            );


            console.log(
                `🔔 User ${userId} joined ${notificationRoom}`
            );
 

            // =====================================
            // Join Room
            // =====================================

            socket.on('join_room', ({ senderId, receiverId }) => {
                const roomId = [senderId, receiverId].sort().join('_');
                socket.join(roomId);
                console.log(`User joined room: ${roomId}`);
            });
            // Send message
            socket.on('send_message', async (messageData) => {
                const roomId = [messageData.sender_id, messageData.receiver_id].sort().join('_');
                const sender_id = messageData.sender_id;
                const receiver_id = messageData.receiver_id;
                const message_text = messageData.message_text;
                
                // Save to database (you'll need to implement this)
                await CommentModel.saveMessage(messageData);
                
                // Emit to specific room
                io.to(roomId).emit('receive_message', { 
                sender_id, 
                receiver_id, 
                message_text, 
                timestamp: new Date().toISOString()  
                });

                // =============================
                // CREATE NOTIFICATION
                // =============================
                await NotificationModel.create({
                    sender_id,
                    receiver_id,
                    message_text,
                    type: 'new_message',
                    post_id: null,
                });
                
                // Send notification to receiver if online
                io.to(`user_${receiver_id}`).emit('notification', {
                type: 'new_message',
                sender_id,
                message_text,
                timestamp: new Date().toISOString()
                });
            });


            // =====================================
            // Chat USERs
            // =====================================


            socket.on("get_chat_users", async () => {
                try {
                    const userId = socket.user.id;

                    const chatResults = await CommentModel.getChatsUsers(userId);
                    const groupchatResults = await GroupChatModel.getUserGroups(userId);

                    socket.emit(
                        "chat_users",   
                        chatResults,
                        groupchatResults    
                    );

                } catch (error) {
                    console.error(
                        "Get chat users error:",
                        error
                    );
                }
            });




    // --- EVENT: join_group_room ---
    socket.on('join_group_room', async ({ groupId }, callback) => {
      try {
        // Critical: Verify group membership first!
        const hasAccess = await GroupChatModel.isMember(groupId, userId);
        
        if (!hasAccess) {
          if (callback) callback({ status: 'error', message: 'Unauthorized access to this group chat.' });
          return;
        }

        const roomName = `group_${groupId}`;
        socket.join(roomName);
        console.log(`🚪 User ${userId} successfully joined room: ${roomName}`);

        if (callback) callback({ status: 'ok', message: `Joined room ${roomName}` });
      } catch (error) {
        console.error('Error joining group room:', error);
        if (callback) callback({ status: 'error', message: 'Internal server error.' });
      }
    });

    

            // =====================================
            // DISCONNECT
            // =====================================

            socket.on(
                "disconnect",
                () => {

                    console.log(
                        `❌ User ${userId} disconnected`
                    );

                }
            );

        }
    );

};


module.exports =
    initSocket;